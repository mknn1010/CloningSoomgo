package webSocket;

public class hhhh {
	
	public static void main(String[] args) {
		
		
		System.out.println("aaaa");
	}

}
