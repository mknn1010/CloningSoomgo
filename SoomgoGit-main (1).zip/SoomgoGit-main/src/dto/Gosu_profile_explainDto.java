package dto;

public class Gosu_profile_explainDto {
	private String explain;

	public Gosu_profile_explainDto(String explain) {
		this.explain = explain;
	}

	public String getExplain() {
		return explain;
	}

	public void setExplain(String explain) {
		this.explain = explain;
	}
	
	


	
	
	
}
