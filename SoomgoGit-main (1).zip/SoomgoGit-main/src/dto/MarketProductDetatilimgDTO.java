package dto;

public class MarketProductDetatilimgDTO {
	private String imgUrl;
	
	public MarketProductDetatilimgDTO(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	
	
}
