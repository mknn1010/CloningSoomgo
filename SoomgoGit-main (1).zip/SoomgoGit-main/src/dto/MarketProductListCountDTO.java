package dto;

public class MarketProductListCountDTO {
	
	private int mProductCnt;

	public int getmProductCnt() {
		return mProductCnt;
	}

	public void setmProductCnt(int mProductCnt) {
		this.mProductCnt = mProductCnt;
	}

	public MarketProductListCountDTO(int mProductCnt) {
		this.mProductCnt = mProductCnt;
	}
	
}
