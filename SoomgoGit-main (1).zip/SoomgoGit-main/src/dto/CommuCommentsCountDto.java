package dto;

public class CommuCommentsCountDto {
	private int commtensCount;

	public CommuCommentsCountDto(int commtensCount) {
		this.commtensCount = commtensCount;
	}
	public int getCommtensCount() {
		return commtensCount;
	}

	public void setCommtensCount(int commtensCount) {
		this.commtensCount = commtensCount;
	}
}
