package dto;

public class CommuPostViewsOnlyOneDto {
	private int count;

	public CommuPostViewsOnlyOneDto(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
