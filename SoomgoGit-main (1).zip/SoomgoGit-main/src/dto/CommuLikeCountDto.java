package dto;

public class CommuLikeCountDto {
	private int countLike;

	public CommuLikeCountDto(int countLike) {
		this.countLike = countLike;
	}

	public int getCountLike() {
		return countLike;
	}

	public void setCountLike(int countLike) {
		this.countLike = countLike;
	}
	
}
