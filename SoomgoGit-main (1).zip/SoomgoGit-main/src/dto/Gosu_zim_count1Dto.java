package dto;

public class Gosu_zim_count1Dto {
	private int score;
	private int g_users_idx;
	
	public Gosu_zim_count1Dto(int score, int g_users_idx) {
		this.score = score;
		this.g_users_idx = g_users_idx;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getG_users_idx() {
		return g_users_idx;
	}

	public void setG_users_idx(int g_users_idx) {
		this.g_users_idx = g_users_idx;
	}
	
	
}
