package dto;

public class Gosu_profile_transaction_countDto {
	private int g_users_idx;

	public Gosu_profile_transaction_countDto(int g_users_idx) {
		this.g_users_idx = g_users_idx;
	}

	public int getG_users_idx() {
		return g_users_idx;
	}

	public void setG_users_idx(int g_users_idx) {
		this.g_users_idx = g_users_idx;
	}
	
	
}
