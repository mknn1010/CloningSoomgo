package dto;

public class CommuPostViewCountDto {
	private int countView;

	public CommuPostViewCountDto(int countView) {
		this.countView = countView;
	}

	public int getCountView() {
		return countView;
	}

	public void setCountView(int countView) {
		this.countView = countView;
	}
	
}
