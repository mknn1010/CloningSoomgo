package dto;

public class CommuPostViewsDto {
	private int count;

	public CommuPostViewsDto(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
